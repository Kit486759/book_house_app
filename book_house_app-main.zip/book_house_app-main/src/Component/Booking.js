import React from 'react'

export default function Booking() {
    return (
        <div>
            <p>This is booking</p>
        </div>
    )
}
