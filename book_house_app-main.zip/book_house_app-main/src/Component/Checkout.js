import React from 'react'

export default function Checkout() {
    return (
        <div>
            <p>This is checkout</p>
        </div>
    )
}
