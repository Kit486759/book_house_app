import React from 'react';
import Feed from './Component/Feed';

function App() {

  return (
        <Feed/>
  );
}

export default App;
